"""
Per-CV pipeline: extract text -> LLM evaluation -> write Eval JSON -> move
the PDF from CV_Buffer to CV_Archive. Batches run in a thread pool sized by
config.MAX_WORKERS (the LLM round-trip is network-bound, so threads scale).
"""

from __future__ import annotations

import json
import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

import config
import cv_evaluator
import cv_extractor

log = logging.getLogger("cv_pipeline")


@dataclass
class CVJob:
    pdf_path: Path
    company_id: str
    job_id: str

    @classmethod
    def from_buffer_path(cls, pdf_path: Path) -> "CVJob":
        """Derive company/job ids from
        Recruitment/<company_id>/CV_Buffer/<job_id>/<cv>.pdf"""
        rel = pdf_path.resolve().relative_to(config.RECRUITMENT_ROOT.resolve())
        parts = rel.parts
        if len(parts) != 4 or parts[1] != config.BUFFER_DIR_NAME:
            raise ValueError(
                f"PDF is not in a <company>/{config.BUFFER_DIR_NAME}/<job_id>/ folder: {pdf_path}"
            )
        return cls(pdf_path=pdf_path, company_id=parts[0], job_id=parts[2])

    @property
    def eval_dir(self) -> Path:
        return config.RECRUITMENT_ROOT / self.company_id / config.EVAL_DIR_NAME / self.job_id

    @property
    def archive_dir(self) -> Path:
        return config.RECRUITMENT_ROOT / self.company_id / config.ARCHIVE_DIR_NAME / self.job_id


def load_job_description(job: CVJob) -> str:
    """Job description lives next to the CVs:
    Recruitment/<comp>/CV_Buffer/<job_id>/job_description.txt
    (it is not a PDF, so the watcher/pipeline never treats it as a CV)."""
    jd_file = job.pdf_path.parent / config.JOB_DESCRIPTION_FILENAME
    if jd_file.is_file():
        text = jd_file.read_text(encoding="utf-8", errors="replace").strip()
        if text:
            return text
    log.warning(
        "No %s for %s/%s -- using default job description",
        config.JOB_DESCRIPTION_FILENAME, job.company_id, job.job_id,
    )
    return config.DEFAULT_JOB_DESCRIPTION


def _unique_path(target: Path) -> Path:
    """Avoid clobbering an archived CV with the same filename."""
    if not target.exists():
        return target
    stem, suffix = target.stem, target.suffix
    for i in range(1, 1000):
        candidate = target.with_name(f"{stem}_{i}{suffix}")
        if not candidate.exists():
            return candidate
    raise FileExistsError(f"Could not find a free archive name for {target}")


def process_cv(pdf_path: Path) -> Path:
    """Run the full pipeline for one CV. Returns the path of the written
    evaluation JSON. Raises on failure (PDF stays in the buffer)."""
    job = CVJob.from_buffer_path(pdf_path)
    started = time.perf_counter()

    extraction = cv_extractor.extract_text(pdf_path)
    if not extraction.text.strip():
        raise ValueError("No text could be extracted from the PDF (empty after OCR fallback)")

    job_description = load_job_description(job)
    assessment, llm_stats = cv_evaluator.evaluate_cv(
        extraction.text, job_description, extraction.detected_job_title
    )

    record = {
        "cv_file": pdf_path.name,
        "company_id": job.company_id,
        "job_id": job.job_id,
        "processed_at": datetime.now(timezone.utc).isoformat(),
        "pipeline": {
            "total_seconds": None,  # filled below
            **llm_stats,
        },
        "extraction": {
            "method": extraction.method,
            "page_count": extraction.page_count,
            "ocr_pages": extraction.ocr_pages,
            "detected_job_title": extraction.detected_job_title,
            "sections_found": sorted(extraction.sections.keys()),
            "text_chars": len(extraction.text),
        },
        **assessment,  # metrics + evaluation
    }
    record["pipeline"]["total_seconds"] = round(time.perf_counter() - started, 3)

    job.eval_dir.mkdir(parents=True, exist_ok=True)
    eval_path = job.eval_dir / f"{pdf_path.stem}.json"
    eval_path.write_text(json.dumps(record, indent=2, ensure_ascii=False), encoding="utf-8")

    # Only after the eval JSON is safely written: cut/move buffer -> archive.
    job.archive_dir.mkdir(parents=True, exist_ok=True)
    pdf_path.replace(_unique_path(job.archive_dir / pdf_path.name))

    log.info(
        "Done %s/%s/%s in %.2fs (extract=%s, model=%s)",
        job.company_id, job.job_id, pdf_path.name,
        record["pipeline"]["total_seconds"], extraction.method, llm_stats.get("model"),
    )
    return eval_path


def write_error_record(pdf_path: Path, error: Exception) -> None:
    """Persist a .error.json next to where the eval would have gone, so failed
    CVs are visible to HR instead of silently stuck in the buffer."""
    try:
        job = CVJob.from_buffer_path(pdf_path)
        job.eval_dir.mkdir(parents=True, exist_ok=True)
        err_path = job.eval_dir / f"{pdf_path.stem}.error.json"
        err_path.write_text(
            json.dumps(
                {
                    "cv_file": pdf_path.name,
                    "failed_at": datetime.now(timezone.utc).isoformat(),
                    "error": f"{type(error).__name__}: {error}",
                    "note": "PDF left in CV_Buffer. Fix the issue and restart the watcher to retry.",
                },
                indent=2,
            ),
            encoding="utf-8",
        )
    except Exception:
        log.exception("Could not write error record for %s", pdf_path)


def process_batch(pdf_paths: list[Path]) -> dict[Path, Exception | Path]:
    """Process many CVs concurrently. Returns {pdf_path: eval_json_path | Exception}."""
    results: dict[Path, Exception | Path] = {}
    if not pdf_paths:
        return results
    log.info("Processing batch of %d CV(s) with %d workers", len(pdf_paths), config.MAX_WORKERS)
    batch_start = time.perf_counter()
    with ThreadPoolExecutor(max_workers=config.MAX_WORKERS) as pool:
        futures = {pool.submit(process_cv, p): p for p in pdf_paths}
        for future in as_completed(futures):
            pdf = futures[future]
            try:
                results[pdf] = future.result()
            except Exception as e:
                log.error("FAILED %s: %s", pdf.name, e)
                results[pdf] = e
    ok = sum(1 for v in results.values() if isinstance(v, Path))
    log.info(
        "Batch finished: %d ok, %d failed in %.1fs",
        ok, len(results) - ok, time.perf_counter() - batch_start,
    )
    return results
